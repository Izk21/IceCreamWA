# QA-Basic
# Basic Selenium Class /Java / Maven project to get you started
# git clone https://github.com/SummerSchoolAcademy/QA-Basic.git     --> to download the brach/ make sure you set up you SSH key
