package com.summerschool.icecreamshop.model;

public enum Type {
    ICE_CREAM, GELATO, DONUTS, MERCHANDISE
}
