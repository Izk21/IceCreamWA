package com.summerschool.icecreamshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcecreamshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
