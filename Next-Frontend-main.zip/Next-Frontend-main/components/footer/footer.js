import React, { Component } from "react";
import Newsletter from "../SubscribeToNewsletter/Newsletter";

const titleFooterSection = [
  "USEFUL INFO",
  "YOU CAN FIND US IN",
  "ABOUT GELATO & DONUTS",
  "NEWSLETTER",
];
const firstRow = ["Privacy Policy", "London, UK", "About Us"];
const secondRow = ["Terms & Conditions", "Bucharest, RO", "Store locator"];
const thirdRow = ["Cookie Policy", "Paris, FR", "Franchise"];
const fourthRow = ["FAQ", "Sofia, BG", "Careers"];
const fifthRow = ["Contact Us"];
const usefulInfo = [
  "Privacy Policy",
  "Terms & Conditions",
  "Cookie Policy",
  "FAQ",
];
const findUs = ["London, UK", "Bucharest, RO", "Paris, FR", "Sofia, BG"];
const aboutGD = [
  "About us",
  "Store locator",
  "Franchise",
  "Careers",
  "Contact us",
];

export default class Footer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isDesktop: false,
      isTablet: false,
    };

    this.updatePredicate = this.updatePredicate.bind(this);
  }
  componentDidMount() {
    this.updatePredicate();
    window.addEventListener("resize", this.updatePredicate);
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.updatePredicate);
  }

  updatePredicate() {
    this.setState({ isDesktop: window.innerWidth > 768 });
    this.setState({
      isTablet: 480 < window.innerWidth && window.innerWidth < 769,
    });
  }

  rowDropdown(id, img) {
    var x = document.getElementById(id);
    let imgElement = document.getElementById(img);
    if (x.style.display === "none") {
      x.style.display = "block";
      imgElement.style.transform = "rotate(180deg)";
    } else {
      x.style.display = "none";
      imgElement.style.transform = "rotate(0deg)";
    }
  }

  render() {
    const isDesktop = this.state.isDesktop;
    const isTablet = this.state.isTablet;
    return (
      <div>
        {isDesktop ? (
          <div className="footer-desktop">
            <div className="row">
              {titleFooterSection.map((item, index) => (
                <div className="col" key={index}>
                  <h4>{item}</h4>
                </div>
              ))}
            </div>

            <div className="row">
              {firstRow.map((item, index) => (
                <div className="col" key={index}>
                  <a href="">{item}</a>
                </div>
              ))}

              <div className="col">
                <Newsletter identifier="desktop" />
              </div>
            </div>

            <div className="row">
              {secondRow.map((item, index) => (
                <div className="col" key={index}>
                  <a href="">{item}</a>
                </div>
              ))}

              <div className="col"></div>
            </div>

            <div className="row">
              {thirdRow.map((item, index) => (
                <div className="col" key={index}>
                  <a href="">{item}</a>
                </div>
              ))}
              <div className="col"></div>
            </div>

            <div className="row">
              {fourthRow.map((item, index) => (
                <div className="col" key={index}>
                  <a href="">{item}</a>
                </div>
              ))}
              <div className="col"></div>
            </div>

            <div className="row">
              <div className="col"></div>
              <div className="col"></div>
              {fifthRow.map((item, index) => (
                <div className="col" key={index}>
                  <a href="">{item}</a>
                </div>
              ))}
              <div className="col"></div>
            </div>
          </div>
        ) : isTablet ? (
          <div className="footer-tablet">
            <div className="blue-part">
              <div className="row">
                <div className="col"></div>
                <div className="col text-center " id="nws">
                  <h4>NEWSLETTER</h4>
                </div>
                <div className="col"></div>
              </div>

              <div className="row">
                <div className="col"></div>
                <div className="col text-center">
                  <Newsletter identifier="tablet" />
                </div>
                <div className="col"></div>
              </div>
            </div>

            <div className="gray-part">
              <div className="row">
                <div className="col">
                  <h4>USEFUL INFO</h4>
                </div>
                <div className="col">
                  <h4>YOU CAN FIND US IN</h4>
                </div>
                <div className="col">
                  <h4>ABOUT GELATO & DONUTS</h4>
                </div>
              </div>

              <div className="row">
                {firstRow.map((item, index) => (
                  <div className="col" key={index}>
                    <a href="">{item}</a>
                  </div>
                ))}
              </div>

              <div className="row">
                {secondRow.map((item, index) => (
                  <div className="col" key={index}>
                    <a href="">{item}</a>
                  </div>
                ))}
              </div>

              <div className="row">
                {thirdRow.map((item, index) => (
                  <div className="col" key={index}>
                    <a href="">{item}</a>
                  </div>
                ))}
              </div>

              <div className="row">
                {fourthRow.map((item, index) => (
                  <div className="col" key={index}>
                    <a href="">{item}</a>
                  </div>
                ))}
              </div>

              <div className="row">
                <div className="col"></div>
                <div className="col"></div>
                {fifthRow.map((item, index) => (
                  <div className="col" key={index}>
                    <a href="">{item}</a>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="footer-mobile">
            <div className="blue-part">
              <div className="row">
                <div className="col"></div>
                <div className="col text-center" id="nws">
                  <h4>NEWSLETTER</h4>
                </div>
                <div className="col"></div>
              </div>

              <div className="row">
                <div className="col"></div>
                <div className="col text-center">
                  <Newsletter identifier="mobile" />
                </div>
                <div className="col"></div>
              </div>
            </div>

            <div className="gray-part">
              <div className="row footer_section">
                <div className="col-10 ">
                  <h4>USEFUL INFO </h4>
                </div>

                <div className="col-2">
                  <input
                    type="image"
                    src="/img.png"
                    id="imag"
                    onClick={() => this.rowDropdown("dropdown", "imag")}
                  />
                </div>

                <div className="row" id="dropdown">
                  {usefulInfo.map((item, index) => (
                    <div className="col" key={index}>
                      <a href="">{item}</a>
                    </div>
                  ))}
                </div>
              </div>

              <div className="row footer_section">
                <div className="col-10">
                  <h4>YOU CAN FIND US IN</h4>
                </div>

                <div className="col-2">
                  <input
                    type="image"
                    src="/img.png"
                    id="imag1"
                    onClick={() => this.rowDropdown("dropdown1", "imag1")}
                  />
                </div>

                <div className="row" id="dropdown1">
                  {findUs.map((item, index) => (
                    <div className="col" key={index}>
                      <a href="">{item}</a>
                    </div>
                  ))}
                </div>
              </div>

              <div className="row">
                <div className="col-10">
                  <h4>ABOUT GELATO & DONUTS</h4>
                </div>

                <div className="col-2">
                  <input
                    type="image"
                    src="/img.png"
                    id="imag2"
                    onClick={() => this.rowDropdown("dropdown2", "imag2")}
                  />
                </div>

                <div className="row" id="dropdown2">
                  {aboutGD.map((item, index) => (
                    <div className="col" key={index}>
                      <a href="">{item}</a>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        <footer className="footer1">
          <div>
            <h1 className="text1">@2021 Gelato & Donuts.</h1>
          </div>
        </footer>
      </div>
    );
  }
}
