import React from "react";
import styles from "./AccountPage.module.css";

export default function AccountPage() {
  return (
    <div className={styles.AccountButton}>
      <button className={styles.button} onClick={() => alert("You signed up")}>
        Sign Up
      </button>
      <button className={styles.button} onClick={() => alert("You logged in")}>
        Log In
      </button>
    </div>
  );
}
