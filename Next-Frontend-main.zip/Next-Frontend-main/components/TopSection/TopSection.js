import React, { Component, useState, useEffect } from 'react';
import topsection from './TopSection.module.css';
import styles from '../../styles/Home.module.css';
import Link from 'next/link';

export default function TopSection(props) {
  const {basket, countBasketProducts} = props;
  const [isOpen, setIsOpen] = useState(false);

  function openNav() {
    document.getElementById("tabletSidebar").style.width = "350px";
    document.getElementById("tabletSidebar").style.display = "block";
    setIsOpen(true);
  }

  function closeNav() {
    document.getElementById("tabletSidebar").style.width = "0";
    document.getElementById("tabletSidebar").style.display = "none";
    setIsOpen(false);
  }

  return (
      <div className={styles.header}>
        {/*Navigation bar*/}
        <div className={topsection.navbar}>
          <ul className={topsection.nav}>

            <li className={topsection.elem} id={topsection.elementMenuButton}>
              <div id={topsection.main}>
                <button className={topsection.openbtn} onClick={isOpen ? closeNav : openNav}>☰ Menu</button>
              </div>
            </li>
            <li className={topsection.elemLogo} id={topsection.elementLogo}><Link href="/"><a>

              <div className={topsection.logo}><img src={props.img}/></div>
            </a></Link></li>
            <li className={topsection.elem} id={topsection.labelGelato}><Link
                href="/gelato"><a>Gelato</a></Link></li>
            <li className={topsection.elem} id={topsection.labelGelatoS}><Link href="/gelatoForSpecialNeeds"><a>Gelato
              for special
              needs</a></Link></li>
            <li className={topsection.elem} id={topsection.labelDonuts}><Link
                href="/donuts"><a>Donuts</a></Link></li>
            <li className={topsection.elem} id={topsection.labelDonutsS}><Link href="/donutsForSpecialNeeds"><a>Donuts
              for special needs</a></Link></li>


            <div className={topsection.navbarright}>
              <Link href="/accountLogin">
                <li className={topsection.btnAccount}>
                  <div className={topsection.accountLabel}>Account</div>
                </li>
              </Link>

              <Link href="/basket">
                <li className={topsection.btnBasket}>
                  <div className={topsection.basketLabel}>
                    Basket
                    <i id = "basketBadge" data-count = {countBasketProducts(basket)}  className={topsection.badge}></i>
                  </div>
                </li>
              </Link>
            </div>
          </ul>
        </div>


        {/*Sidebar for tablet and mobile versions */}

        <div id="tabletSidebar" className={topsection.sidebar}>

          <button className={topsection.closebtn} onClick={closeNav}>&#x2715;</button>

          <center>
            <div className={topsection.sidebarElement}>Menu</div>
          </center>

          <div>
            <hr className={topsection.breakLineTitle}></hr>
          </div>

          <Link href="/"><a className={topsection.sidebarListElement}>Home</a></Link>
          <Link href="/gelato"><a className={topsection.sidebarListElement}>Gelato</a></Link>
          <Link href="/gelatoForSpecialNeeds"><a className={topsection.sidebarListElement}>Gelato for special
            needs</a></Link>
          <Link href="/donuts"><a className={topsection.sidebarListElement}>Donuts</a></Link>
          <Link href="/donutsForSpecialNeeds"><a className={topsection.sidebarListElement}>Donuts for special
            needs</a></Link>

          <div className={topsection.bottomSidebar}> {/*contains Account and Basket buttons*/}

            <div>
              <hr className={topsection.breakLine}></hr>
            </div>

            <Link href="/accountLogin"><a className={topsection.btnMenuAccount}>
              <div className={topsection.labelMenu}>Account</div>
            </a></Link>

            <div>
              <hr className={topsection.breakLine}></hr>
            </div>

            <Link href="/basket">
              <a className={topsection.btnMenuBasket}>
                <div className={topsection.labelMenu}>Basket</div>
              </a>
            </Link>
          </div>
        </div>

      </div>);
}