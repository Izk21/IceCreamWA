import React, { useState, useEffect } from "react";
import getTopSellingData from "./api/getTopSellingData";

import getAllGelato from "./api/getAllGelato";
import Head from "next/head";
import styles from '../styles/Home.module.css'
import CategoryBanner from '../components/CategoryBanner/CategoryBanner'
import ItemSection from "../components/ItemSection/ItemSection";
import ItemSectionPaginated from "../components/ItemSection/ItemSectionPaginated";
import Footer from '../components/footer/footer'
import 'bootstrap/dist/css/bootstrap.min.css';
import TopSection from "../components/TopSection/TopSection";
import CustomBreadcrumbs from "../components/breadcrumb/Breadcrumb";
import countBasketProducts from "../utility/countBasketProducts";

export default function Gelato() {
  const [basket, setBasket] = useState([]);
  const [isRetrievingProducts, setRetrievingProducts] = useState(true);
  const [topgelato, setTopGelato] = useState([]);
  const [gelato, setGelato] = useState({totalCount: 0, values: []});

  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(3);

  const [desktop, setDesktop] = useState(true);
  const [tablet, setTablet] = useState(true);

  if (process.browser) {
    window.matchMedia("(min-width: 769px)").addListener(e => setDesktop(e.matches));    
  }

  const addToBasket = (product) => {
    const productExists = basket.find(p => p.id === product.id);
    if(productExists){
      const newBasket = basket.map(p => p.id === product.id ? {...productExists, qty:productExists.qty + 1} : p);
      setBasket(newBasket);
      window.localStorage.setItem("basket", JSON.stringify(newBasket));
    }  
    else{
      const newBasket = [...basket, {...product, qty: 1}];
      window.localStorage.setItem("basket", JSON.stringify(newBasket));
      setBasket(newBasket);
    }
  }  

  async function fetchData(pageIndex, pageSize) {
    try {
      const topgelato = await getTopSellingData("GELATO");
      const gelato = await getAllGelato(pageIndex, pageSize);
      setRetrievingProducts(false);
      setTopGelato(topgelato);
      setGelato(gelato);
    } catch (error) {
      console.error(error);
    }
  }
  useEffect(() => {
    const otherBasket = window.localStorage.getItem("basket");
    if(otherBasket){
      setBasket(JSON.parse(otherBasket));
    }
    else{
      setBasket([]);
    }
  }, []);
  useEffect(() => {
    fetchData(pageIndex, pageSize);
  }, [pageIndex, pageSize]);

  useEffect(() => {
      if (desktop) {
        setPageSize(12);
      } else {
        setPageSize(8);
      }
  }, [ desktop])

    return (
      <div className={styles.container}>

        <Head>
          <title>Ice Cream Site-Gelato</title>
          <meta
            name="viewport"
            content="width=device-width,initial-scale=1"
          ></meta>
        </Head>
          
        <TopSection  countBasketProducts = {countBasketProducts} basket = {basket}  img="group1327.svg">
        </TopSection>

          <CustomBreadcrumbs />

        <main className={styles.main}>
            
            {/* Nu avem inca poze pentru gelato plp */}
          <CategoryBanner img="/Group 1446.png" text="gelato"/>
          <ItemSection addToBasket = {addToBasket} title='top selling gelato' url="#" itemlist={ topgelato }/>
          <ItemSectionPaginated addToBasket = {addToBasket} title='all gelato' itemlist={gelato} pageIndex={pageIndex} setPageIndex={setPageIndex}/>

        </main>

        <div className="footer">
        <Footer />
      </div>

      </div>
   )
}
