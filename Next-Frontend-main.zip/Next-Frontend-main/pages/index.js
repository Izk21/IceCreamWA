import React, { useState, useEffect } from "react";
import getMerchandise from "./api/getMerchandise";
import getTopSellingData from "./api/getTopSellingData";
import Head from "next/head";
import styles from '../styles/Home.module.css'
import Categories from '../components/CategorySection/Categories'
import ItemSection from "../components/ItemSection/ItemSection";
import {getProductsFromBasket} from "./api/getBasketProducts";
import Footer from '../components/footer/footer'
import 'bootstrap/dist/css/bootstrap.min.css';
import TopSection from "../components/TopSection/TopSection";
import getCategories from "./api/getCategories";
import CustomBreadcrumbs from "../components/breadcrumb/Breadcrumb";
import countBasketProducts from "../utility/countBasketProducts";

export async function getStaticProps() {
  const environmentVariables = {
    BACKEND_API: process.env.BACKEND_API
  }

  return {
    props: {
      environmentVariables
    }
  }
}
export default function Home({environmentVariables}) {

  
  const [isRetrievingProducts, setRetrievingProducts] = useState(true);
  const [merchandise, setMerchandise] = useState([]);
  const [topicecream, setTopIcecream] = useState([]);
  const [topdonuts, setTopDonuts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [basketelements,setBasketElements] = useState([]);
  const [basket, setBasket] = useState([]);

  const addToBasket = (product) => {
    const productExists = basket.find(p => p.id === product.id);
    if(productExists){
      const newBasket = basket.map(p => p.id === product.id ? {...productExists, qty:productExists.qty + 1} : p);
      setBasket(newBasket);
      window.localStorage.setItem("basket", JSON.stringify(newBasket));
    }  
    else{
      const newBasket = [...basket, {...product, qty: 1}];
      window.localStorage.setItem("basket", JSON.stringify(newBasket));
      setBasket(newBasket);
    }
  }

  async function fetchData() {
    try {
      const merchandise = await getMerchandise();
      const topicecream = await getTopSellingData("GELATO");
      const topdonuts = await getTopSellingData("DONUTS");
      const categories = await getCategories();

      const basketelements = await getProductsFromBasket(2);

      setRetrievingProducts(false);
      setMerchandise(merchandise);
      setTopIcecream(topicecream);
      setTopDonuts(topdonuts);

      setBasketElements(basketelements);

      setCategories(categories);
    } catch (error) {
      console.error(error);
    }
  }
  useEffect(() => {
    const otherBasket = window.localStorage.getItem("basket");
    if(otherBasket){
      setBasket(JSON.parse(otherBasket));
    }
    else{
      setBasket([]);
    }
    fetchData();
  }, []);

    return (



      <div className={styles.container}>

        <Head>
          <title>Ice Cream Site</title>
          <meta
            name="viewport"
            content="width=device-width,initial-scale=1"
          ></meta>
        </Head>
          

        <TopSection countBasketProducts = {countBasketProducts} basket = {basket} img="group1327.svg"> </TopSection>

        <CustomBreadcrumbs />

      <main className={styles.main}>

        <Categories itemlist={categories}/>
        <ItemSection addToBasket = {addToBasket} showMore={true} title='top selling ice cream & gelato' url="/gelato" itemlist={topicecream}/>
        <ItemSection addToBasket = {addToBasket} showMore={true} title='top selling donuts' url="/donuts" itemlist={topdonuts}/>
        <ItemSection addToBasket = {addToBasket} title='merchandise' itemlist={merchandise}/>

      </main>

      <div className="footer">
        <Footer />
      </div>

    </div>
  )
}
