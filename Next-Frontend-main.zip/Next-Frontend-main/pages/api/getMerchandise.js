export default async function getProducts() {
  const getData = async () => {
    const res = [
      {
        id: 1,
        picture: "/T-Shirt.png",
        name: "Basic T Shirt",
        description:
          "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam",
        price: " 2.5",
      },
      {
        id: 2,
        picture: "/Mug.png",
        name: "Simple Mug",
        description:
          "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam",
        price: " 2.5",
      },
    ];

    return res;
  };
  let merchandise;
  try {
    merchandise = await getData();
  } catch (error) {
    console.error(error);
  }
  return merchandise;
}
