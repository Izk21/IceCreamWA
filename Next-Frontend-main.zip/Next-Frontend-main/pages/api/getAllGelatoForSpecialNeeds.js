export default async function getGelatoForSpecialNeeds(pageIndex, pageSize) {
    const getData = async () => {
      const res = await fetch('https://icecreamshop-rkbemzbp2q-ew.a.run.app/products/special');
      const data = await res.json();

      const dataFiltered = data?.filter(el => el.type.includes("GELATO")) ?? [];

      return {totalPages: Math.ceil(dataFiltered.length/pageSize), values: dataFiltered.slice(pageIndex*pageSize, (pageIndex+1)*pageSize)};
    };

    let gelatoForSpecialNeeds;
    try {
        gelatoForSpecialNeeds = await getData();
    } catch (error) {
      console.error(error);
    }
    gelatoForSpecialNeeds.values = gelatoForSpecialNeeds.values.map(item => (
      {
        id: item.id,
        pictureBig: item.photoUrlsBig[0],
        picture: item.photoUrlsMedium[0],
        pictureSmall: item.photoUrlsSmall[0],
        name: item.title, 
        description: item.shortDescription, 
        price: item.price
      }
    ))
    return gelatoForSpecialNeeds;
}