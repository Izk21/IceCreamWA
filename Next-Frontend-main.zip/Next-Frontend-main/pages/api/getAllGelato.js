// TODO BACKEND: totalPages must be returned by an api endpoint
// there is no endpoint for totalPages 

export default async function getAllGelato(pageIndex, pageSize) {
    const getData = async () => {
      const res = await fetch('https://icecreamshop-rkbemzbp2q-ew.a.run.app/products');
      const data = await res.json();

      const dataFiltered = data?.filter(el => el.type.includes("GELATO")) ?? [];

      return {totalPages: Math.ceil(dataFiltered.length/pageSize), values: dataFiltered.slice(pageIndex*pageSize, (pageIndex+1)*pageSize)};
    };

    let gelato;
    try {
      gelato = await getData();
    } catch (error) {
      console.error(error);
    }
    gelato.values = gelato.values.map(item => (
      {
        id: item.id,
        pictureBig: item.photoUrlsBig[0],
        picture: item.photoUrlsMedium[0],
        pictureSmall: item.photoUrlsSmall[0],
        name: item.title, 
        description: item.shortDescription, 
        price: item.price
      }
    ))
    return gelato;
}