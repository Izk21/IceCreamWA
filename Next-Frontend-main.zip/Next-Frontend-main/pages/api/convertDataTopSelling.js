export default async function convertDataTopSelling(data) {
    data = data.map(item => (
        {
          id: item.id,
          pictureBig: item.photoUrlsBig[0],
          picture: item.photoUrlsMedium[0],
          pictureSmall: item.photoUrlsSmall[0],
          name: item.title, 
          description: item.shortDescription, 
          price: item.price
        }
      ))

    return data;
}