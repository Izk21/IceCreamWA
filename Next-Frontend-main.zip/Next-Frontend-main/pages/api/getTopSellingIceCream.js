// TODO this is mock data and it's expected to be changed
export default async function getTopSellingIceCream() {
    const getData = async () => {
      const res = [
        {
          id: 1,
          picture: "/icecream1.png",
          name: "Pistachio Cream",
          description:
          'Treat yourself with icecream infused with smooth Bourbon sprinkled',
          price: "$ 2.50",
      },
      {
          id: 2,
          picture: "/icecream2.png",
          name: "Watermelon Ice Cream",
          description:
          'Treat yourself with icecream infused with smooth Bourbon sprinkled',
          price: "$ 2.50",
      },
      {
          id: 3,
          picture: "/icecream3.png",
          name: "Strawberry Ice Cream",
          description:
          'Treat yourself with icecream infused with smooth Bourbon sprinkled',
          price: "$ 2.50",
      },
      {
          id: 4,
          picture: "/icecream4.png",
          name: "Watermelon Ice Cream",
          description:
          'Treat yourself with icecream infused with smooth Bourbon sprinkled',
          price: "$ 2.50",
      }
      ];
  
      return res;
    };
    let topdonuts;
    try {
      topdonuts = await getData();
    } catch (error) {
      console.error(error);
    }
    return topdonuts;
}