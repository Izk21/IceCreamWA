export default function countBasketProducts(basket){
    
    let counter = 0;
    for(let prod of basket){
      counter += prod.qty;
    }
    return counter;
  }